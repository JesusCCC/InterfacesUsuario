/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacesusuario2210;

import ico.fes.iu.MiVentana;
import ico.fes.iu.MiVentanaVersion2;
import ico.fes.iu.swing.VentanaSwing;

/**
 *
 * @author arman
 */
public class InterfacesUsuario2210 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //MiVentana w =new MiVentana();
        MiVentanaVersion2 v2 = new MiVentanaVersion2();
        VentanaSwing vs = new VentanaSwing();
    }
    
}
